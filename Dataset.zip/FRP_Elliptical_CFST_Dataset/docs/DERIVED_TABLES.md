# Derived tables and audits

The files below contain transparent calculations or packaging metadata. Their values are not additional experimental observations.

| Table | Field | Definition |
| --- | --- | --- |
| `concentric_validation_pairs.csv` | `case_id`, `base_configuration_id` | Identifiers linking the experimental and numerical records |
| `concentric_validation_pairs.csv` | `experimental_source_excel_row`, `FEM_source_excel_row` | Original rows of the two responses in the primary ML workbook |
| `concentric_validation_pairs.csv` | `experimental_Y_kN`, `FEM_Y_kN` | Original experimental and FEM capacities in kN |
| `concentric_validation_pairs.csv` | `FEM_over_experimental` | FEM capacity divided by experimental capacity |
| `fem_curve_summary.csv` | `case_id`, `source_file` | Case identifier and original response workbook path |
| `fem_curve_summary.csv` | `curve_row_count` | Number of available nonblank rows in that response block |
| `fem_curve_summary.csv` | `target_Y_kN` | Capacity stored in the test matrix and matching ML record |
| `fem_curve_summary.csv` | `curve_peak_RF_kN` | Maximum recorded RF in the available response samples |
| `fem_curve_summary.csv` | `peak_minus_target_kN` | Recorded RF maximum minus stored target |
| `fem_curve_summary.csv` | `peak_source_excel_row`, `peak_displacement_mm` | Row and recorded U3 value at the maximum RF |
| `source_formula_audit.csv` | `case_id`, `source_file`, `source_cell` | Original E33 formula location |
| `source_formula_audit.csv` | `formula`, `cached_value`, `cache_present` | Original Excel formula, its stored cache and whether that cache exists |
| `fem_predictor_collisions.csv` | `collision_id` | Identifier created to group records with an identical X1–X5 vector |
| `fem_predictor_collisions.csv` | `record_id`, `source_excel_row`, `case_id` | Identifiers and original row of each retained case |
| `fem_predictor_collisions.csv` | `X1`–`X5`, `Y` | Original features and responses, with the units defined in the main dictionary |
| `test_archive_members.csv` | `archive_member`, `size_bytes`, `sha256` | Original RAR member name, byte count and SHA-256 of unchanged extracted bytes |
| `file_manifest.csv` | `relative_path`, `size_bytes`, `sha256` | Release-file relative path, byte count and integrity hash |

The manifest and `checksums.sha256` list every included data, documentation and script file except the two integrity-list files themselves. Bytecode caches are excluded from the release. The source-cell matrix exports retain every original row and positional column, including headings; they are preservation exports rather than additional model-training datasets.
