# Dataset scope and use

The dataset concerns short FRP-confined elliptical concrete-filled steel tube columns. The supplied matrices specify a height of 500 mm, steel thickness of 3 mm, steel yield strength of 785 MPa and concrete strength of 32.5 MPa. The three outer dimension pairs are 194 × 194 mm, 230 × 154 mm and 252 × 126 mm. FRP layer count ranges from zero to three, with total recorded thickness from zero to 0.501 mm.

The five predictor columns are combined structural descriptors. They retain the source workbook's values and precision. In particular, the nominal aspect-ratio family described as 1.5 has an actual recorded ratio of 230/154 = 1.4935064935064934. Source-derived area/resistance values are preserved rather than silently recomputed using a different numerical approximation for pi or section geometry.

`X4` stores the recorded eccentricity ratio. Source matrices show normalization by the major dimension for some cases and the minor dimension for others. `lambda_normalizing_dimension` records which supplied dimension satisfies the recorded ratio. For the circular 194 × 194 mm family, these dimensions coincide. This numerical check does not infer missing loading-axis metadata.

The 96 FEM cases consist of 12 base configurations and their eccentric variants. Four circular-family cases have four recorded variants each; eight elliptical-family cases have ten variants each. The 12 experimental responses are configuration-level reference capacities associated with the I/II specimen labels used in the source. Individual replicate-level measurements, additional observations and eccentric experimental tests are not created by this release.

The FEM/experimental comparison table calculates a ratio for each matched concentric configuration. The mean of those 12 ratios is 0.9953308949531545. This descriptive check matches the manuscript's rounded value of 0.995. It does not establish independent experimental accuracy under eccentric loading.

The response-curve summary calculates the maximum recorded RF value from each archived curve, the row containing it and its difference from the stored ML target. This is an audit calculation over the available response samples. It is not an alternative target definition or a replacement for the source's recorded ultimate capacities.

For future model evaluation, `base_configuration_id` provides a source-derived grouping key. Fit preprocessing and select model settings within training data. Keep matched configurations and their variants together when evaluating unseen base configurations. The source matrix's five predictors omit an explicit loading-axis input, and eight input-vector pairs correspond to different capacities; these limitations are preserved in the audit.

The attached data permit the source table, source joins and available response curves to be inspected and regenerated. Full solver reruns require the original Abaqus model definitions and solver settings, which were not included in the source archive. The included scripts do not claim to reproduce the historical random-partition scores, Bayesian optimization, SHAP results, GUI or all numerical results of the manuscript.
