# Source provenance and mapping

## Original source files

The file `data/raw/Data_for_ML_Topic37.xlsx` is an unchanged byte copy of the supplied `Data for ML (Topic-37)(1).xlsx`. Its sole worksheet, `Sheet1`, has headers `X1`, `X2`, `X3`, `X4`, `X5`, `Y` in Excel row 1 and 108 numeric rows in Excel rows 2–109.

The folder `data/raw/TESTS` contains all 222 regular files extracted from `TESTS(1).rar`. The relative folder structure, original filenames and file contents are preserved. Archive entries are listed with their SHA-256 hashes in `metadata/test_archive_members.csv`. The original archive hash is retained in `metadata/source_provenance.json`; the redundant compressed RAR container is not included.

The supplied manuscript and supplementary document were used to establish the intended feature definitions, response-origin distinction and scope. Their filenames and SHA-256 hashes are recorded for provenance; the Word documents are not redistributed in this dataset package.

## Row origins

| Excel rows in the ML workbook | Response origin | Count | Matching source |
| --- | --- | ---: | --- |
| 2–41 | FEM: 12 concentric and 28 eccentric | 40 | Group-1 test matrix |
| 42–53 | Experimental concentric capacities | 12 | Group-1 experimental Load field |
| 54–81 | FEM eccentric capacities | 28 | Group-2 test matrix |
| 82–109 | FEM eccentric capacities | 28 | Group-3 test matrix |

FEM records are matched using all six numeric cells. Experimental records are matched using the five feature cells and the experimental Load field. This provides a unique source match for every record. The experimental rows are not selected merely because eccentricity is zero: 12 FEM rows are also concentric.

`record_id` is a new convenience identifier based on the original ML workbook order. `source_excel_row` retains the original one-based Excel row. `case_id` combines archive group and FEM specimen identifier, such as `G1-S156`. This is necessary because S269–S296 are reused in all three archive groups.

## Test-matrix export

All XLS test matrices contain two pre-header rows, a detailed header row at Excel row 3 and numeric configuration rows beginning at row 4. They are copied to `data/source_exports/test_matrix_G1_source_cells.csv`, `test_matrix_G2_source_cells.csv` and `test_matrix_G3_source_cells.csv` with generic positional column names. Original headings and pre-header rows are preserved as cell values.

The matrices' last six columns contain the same numeric feature/response sequence as the ML workbook. The older matrix headings `X5` and `X6` denote the fourth and fifth predictor, respectively. In the ML workbook these columns are called `X4` and `X5`. The annotated metadata uses the ML workbook's names; the direct source-cell exports retain the original headings.

## Response curves and formula caches

Each response workbook supplies four columns per case: `Increment`, `E33`, `U3`, and `RF (kN)`. The long-format export retains the source workbook, sheet, row, title cell and start column for each observation. Blank trailing cells and formatting-only regions do not become invented response observations.

For `G2-S287`, the title is stored at **BW1**, above its U3 column. The case's four-column response block begins at **BU**, identified from the explicit row-2 labels. The export preserves `source_title_cell=BW1` and `source_start_column=BU`. The source workbook itself is unchanged.

There are 761 E33 formula cells with stored numeric caches. Their original formulas and cached values are retained in `metadata/source_formula_audit.csv`. Formulas such as U3/500 provide a nominal displacement/height quantity; the package does not reinterpret them as independently recorded local strain-field measurements.

## Changes made in this release

The release adds identifiers, source coordinates, response-origin labels, dictionary, CSV exports, numerical comparisons, integrity hashes and loading utilities. It does not change, round, replace, impute or simulate any of the six original numeric columns. Empty optional metadata remains blank; numeric zeros retain their source meaning.
