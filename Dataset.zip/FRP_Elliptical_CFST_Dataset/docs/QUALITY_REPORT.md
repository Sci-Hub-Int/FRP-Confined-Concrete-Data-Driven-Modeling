# Data quality and consistency report

## Verified source fidelity

The 648 numeric cells in the 108-row ML matrix are preserved. Every FEM record has a unique six-cell match in a supplied test matrix. Every experimental record has a unique match to the corresponding experimental Load field and feature vector. All 96 FEM cases are linked to available archived curves.

The primary numerical table has no missing or non-finite feature/target values and no exact duplicate six-column records. The experimental subset contains 12 concentric records, and the FEM subset contains 12 concentric plus 84 eccentric records. The 96 FEM records cover 12 base configurations. All 216 TIFF files and all source workbooks are preserved for validation.

## Identical predictor vectors

Eight pairs of FEM cases have identical five-predictor vectors but different capacities. The pairs correspond to original ML Excel rows 30/38, 31/39, 32/40, 33/41, 98/106, 99/107, 100/108 and 101/109. These are not exact duplicate records and are retained. Their record identifiers, case identifiers, original row numbers and numeric values are listed in `metadata/fem_predictor_collisions.csv`.

The five-feature ML table does not identify the loading axis. Group-1 test-matrix notes distinguish weak and strong axes for its eccentric cases. The equivalent field is not explicitly supplied in Group-2/3 matrices. The package retains that distinction between recorded and absent metadata.

## Curve and target differences

The following three archived maxima differ from the capacity recorded in both the primary ML workbook and test matrix:

| Case | Stored target Y (kN) | Maximum archived RF (kN) | RF maximum minus Y (kN) |
| --- | ---: | ---: | ---: |
| G1-S155 | 2542.69 | 2639.77 | 97.08 |
| G1-S164 | 2202.02 | 2232.32 | 30.30 |
| G1-S166 | 2339.13 | 2343.20 | 4.07 |

The cause of these source differences is not established by the attachments. The release retains both values and does not select a replacement capacity. The remaining 93 archived curve maxima agree with their stored targets within 0.01 kN.

## Headers and units

The Group-2 S287 title is offset relative to its four-column response block. Its response columns are identified from the explicit variable labels, and both original title and data coordinates are retained. Legacy test-matrix names X5/X6 are documented as the fourth/fifth predictor of the ML table. The nominal aspect ratio 1.5 is preserved numerically as the source value 230/154.

X1 has units N/mm, X2 and X3 have units N, and Y has units kN. The original source's zeros in unwrapped FRP configurations are retained. No missing observations are replaced with zeros.

## Formula and integrity checks

The available curves have 959 nonblank response rows and 761 E33 formula cells. All 761 formula cells have stored caches. The original formulas are listed separately and the cached values are used in the CSV export.

`scripts/validate_dataset.py` verifies file hashes, source numeric fidelity, all source joins, curve coordinates, response-origin counts and TIFF readability. Passing these checks establishes faithful packaging of the supplied records; the three recorded curve/target differences remain visible. `metadata/quality_report.json` contains the machine-readable audit results.
