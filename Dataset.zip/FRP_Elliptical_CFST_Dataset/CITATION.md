# Citation information

## Related manuscript

Hou Lei; Haytham F. Isleem; Hussam Sulaiman.

**Data-Driven Prediction of Load-Bearing Capacity in FRP-Confined Elliptical CFST Columns Using Ensemble Machine Learning Techniques.**

The author names and title above are transcribed from the supplied manuscript. No journal, year of publication, publication DOI or published status was supplied for this dataset citation.

## Experimental reference source

The supplied manuscript attributes the concentric experimental reference capacities to:

J. J. Zeng, S. D. Liang, Y. L. Li, Y. C. Guo and G. Y. Shan. Compressive behavior of FRP-confined elliptical concrete-filled high-strength steel tube column. Composite Structures, 266, 113808 (2021).

This reference identifies the source recorded in the manuscript. The package does not claim an independently obtained experimental dataset or recreate individual specimen-pair results.

## Dataset deposit

Dataset title: **FRP confined elliptical CFST column dataset**.

Release version: **1.0.0**.

Release preparation date: **2026-10-13**.

After deposit, cite the dataset creators, repository name and persistent identifier recorded by the repository. A dataset DOI and license have not been assigned within this package.
