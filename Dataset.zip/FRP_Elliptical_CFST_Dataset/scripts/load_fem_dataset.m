function [X, y, groups, records] = load_fem_dataset(datasetRoot)
%LOAD_FEM_DATASET Read the 96 FEM cases without scaling or changing values.
% [X,y,groups,records] = load_fem_dataset;
% Add this scripts folder to the MATLAB path before calling the function.
% X column order: X1 [N/mm], X2 [N], X3 [N], X4 [-], X5 [-].
% y is ultimate capacity Y [kN]. groups identifies 12 base configurations.
% Fit preprocessing using training records only. Keep matched configurations
% together when evaluating generalization to unseen configurations.

if nargin < 1 || isempty(datasetRoot)
    datasetRoot = fileparts(fileparts(mfilename('fullpath')));
end
datasetPath = fullfile(datasetRoot,'data','processed','fem_ml.csv');
assert(isfile(datasetPath),'Dataset file not found: %s',datasetPath);
records = readtable(datasetPath,'TextType','string','VariableNamingRule','preserve');
required = {'X1','X2','X3','X4','X5','Y','base_configuration_id','response_origin'};
assert(all(ismember(required,records.Properties.VariableNames)), ...
    'Unexpected dataset column names.');
X = records{:,{'X1','X2','X3','X4','X5'}};
y = records.Y;
groups = records.base_configuration_id;
assert(height(records)==96 && all(records.response_origin=="FEM"), ...
    'Expected 96 FEM records.');
assert(all(isfinite(X),'all') && all(isfinite(y)), ...
    'Non-finite numeric values found.');
assert(numel(unique(groups))==12,'Expected 12 base configurations.');
end
