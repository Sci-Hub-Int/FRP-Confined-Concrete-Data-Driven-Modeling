"""Dependency-free loader for the 96 FEM feature/target records."""
from pathlib import Path
import csv
import math

FEATURES = ['X1', 'X2', 'X3', 'X4', 'X5']


def load_fem_dataset(root=None):
    root = Path(root) if root is not None else Path(__file__).resolve().parents[1]
    with (root / 'data/processed/fem_ml.csv').open(encoding='utf-8', newline='') as handle:
        rows = list(csv.DictReader(handle))
    X = [[float(r[k]) for k in FEATURES] for r in rows]
    y = [float(r['Y']) for r in rows]
    groups = [r['base_configuration_id'] for r in rows]
    if len(rows) != 96 or any(r['response_origin'] != 'FEM' for r in rows):
        raise ValueError('Expected the 96 FEM records only')
    if not all(math.isfinite(v) for row in X for v in row) or not all(map(math.isfinite, y)):
        raise ValueError('Non-finite numeric value')
    return X, y, groups, rows


if __name__ == '__main__':
    X, y, groups, rows = load_fem_dataset()
    print(f'Loaded {len(y)} FEM records, {len(X[0])} features and {len(set(groups))} base configurations.')
    print('Feature order:', ', '.join(FEATURES))
    print('Target: Y (kN). Fit any transformation within training folds only.')
