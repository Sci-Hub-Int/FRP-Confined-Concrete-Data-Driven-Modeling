"""Validate file integrity, source fidelity, joins, curves and response origins."""
from pathlib import Path
import csv
import hashlib
import json
import math
import sys
from collections import Counter

import openpyxl
from PIL import Image

from prepare_dataset import read_matrices, read_records, read_curves

ROOT = Path(__file__).resolve().parents[1]


def load_csv(path):
    with path.open(encoding='utf-8', newline='') as handle:
        return list(csv.DictReader(handle))


def check_export(rows, reference, numeric_fields):
    if len(rows) != len(reference):
        raise AssertionError('CSV row count differs from source')
    for actual, source in zip(rows, reference):
        for key, value in source.items():
            expected = '' if value is None else str(value)
            if key in numeric_fields and expected != '':
                # Python repr -> CSV -> float is an exact round trip for source doubles.
                if float(actual[key]) != float(value):
                    raise AssertionError(f'Numeric source changed: {key}: {actual[key]} vs {value}')
            elif actual[key] != expected:
                raise AssertionError(f'Source field changed: {key}')


def main():
    failures = []
    checked_files = 0
    for item in load_csv(ROOT / 'metadata/file_manifest.csv'):
        path = ROOT / item['relative_path']
        if not path.is_file():
            failures.append('Missing: ' + item['relative_path'])
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != item['sha256'] or path.stat().st_size != int(item['size_bytes']):
            failures.append('Integrity mismatch: ' + item['relative_path'])
        checked_files += 1
    if failures:
        raise AssertionError('\n'.join(failures))
    cases, _ = read_matrices(ROOT)
    records = read_records(ROOT, cases)
    curves, summary, formulas = read_curves(ROOT, cases)
    check_export(load_csv(ROOT / 'data/processed/records_all.csv'), records,
                 {'X1','X2','X3','X4','X5','Y','source_excel_row'})
    fem = [r for r in records if r['response_origin'] == 'FEM']
    experimental = [r for r in records if r['response_origin'] == 'experimental']
    check_export(load_csv(ROOT / 'data/processed/fem_ml.csv'), fem, {'X1','X2','X3','X4','X5','Y','source_excel_row'})
    check_export(load_csv(ROOT / 'data/processed/experimental_concentric.csv'), experimental,
                 {'X1','X2','X3','X4','X5','Y','source_excel_row'})
    check_export(load_csv(ROOT / 'data/processed/fem_case_metadata.csv'), cases,
                 {k for r in cases for k, v in r.items() if isinstance(v, (int, float))})
    check_export(load_csv(ROOT / 'data/processed/fem_curves_long.csv'), curves,
                 {'source_excel_row','increment','E33','U3_mm','RF_kN'})
    check_export(load_csv(ROOT / 'data/processed/fem_curve_summary.csv'), summary,
                 {k for r in summary for k, v in r.items() if isinstance(v, (int, float))})
    check_export(load_csv(ROOT / 'metadata/source_formula_audit.csv'), formulas, {'cached_value'})
    report = json.loads((ROOT / 'metadata/quality_report.json').read_text(encoding='utf-8'))
    assert Counter(r['response_origin'] for r in records) == {'FEM':96,'experimental':12}
    assert report['record_count'] == len(records) == 108
    assert report['curve_row_count'] == len(curves)
    assert report['missing_formula_cache_count'] == 0
    assert len({r['case_id'] for r in fem}) == len(summary) == 96
    assert len({r['base_configuration_id'] for r in fem}) == 12
    original = openpyxl.load_workbook(ROOT / 'data/raw/Data_for_ML_Topic37.xlsx', data_only=True, read_only=True)
    expected = list(original['Sheet1'].iter_rows(values_only=True))[1:]
    for row, source in zip(records, expected):
        assert tuple(row[k] for k in ['X1','X2','X3','X4','X5','Y']) == tuple(source)
    original.close()
    images = list((ROOT / 'data/raw/TESTS').rglob('*.tif'))
    assert len(images) == 216
    for path in images:
        with Image.open(path) as image:
            image.verify()
    print(json.dumps({'status':'PASS','manifest_files_verified':checked_files,
                      'source_numeric_cells_verified':108*6,'FEM_case_joins_verified':96,
                      'experimental_pairs_verified':12,'curve_cases_verified':96,
                      'curve_rows_verified':len(curves),'TIFF_files_verified':len(images)},indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'VALIDATION FAILED: {exc}', file=sys.stderr)
        raise
