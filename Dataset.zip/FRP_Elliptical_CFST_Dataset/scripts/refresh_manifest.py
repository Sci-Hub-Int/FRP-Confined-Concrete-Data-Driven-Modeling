"""Refresh checksums after an intentional rebuild or release update."""
from pathlib import Path
import csv
import hashlib

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {'metadata/file_manifest.csv', 'checksums.sha256'}


def main():
    rows = []
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        relative = path.relative_to(ROOT).as_posix()
        if relative in EXCLUDED:
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        rows.append({'relative_path':relative, 'size_bytes':path.stat().st_size, 'sha256':digest})
    (ROOT / 'metadata').mkdir(exist_ok=True)
    with (ROOT / 'metadata/file_manifest.csv').open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=['relative_path','size_bytes','sha256'])
        writer.writeheader()
        writer.writerows(rows)
    (ROOT / 'checksums.sha256').write_text(
        ''.join(f"{r['sha256']}  {r['relative_path']}\n" for r in rows), encoding='utf-8')
    print(f'Wrote SHA-256 records for {len(rows)} files. Manifest and checksum list exclude themselves.')


if __name__ == '__main__':
    main()
