"""Export the supplied Excel/XLS records without changing source measurements.

Run from any directory: python scripts/prepare_dataset.py
Existing generated files require the explicit --overwrite option.
"""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import math
import re
import statistics
from pathlib import Path

import openpyxl
import xlrd

FEATURES = ['X1', 'X2', 'X3', 'X4', 'X5']
VALUES = FEATURES + ['Y']
ROOT = Path(__file__).resolve().parents[1]


def close(a, b):
    return isinstance(a, (int, float)) and isinstance(b, (int, float)) and math.isclose(
        a, b, rel_tol=1e-12, abs_tol=1e-8)


def write_csv(path, rows, columns):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read_matrices(root):
    cases = []
    matrix_exports = []
    for group in range(1, 4):
        folder = root / 'data/raw/TESTS' / f'Group-{group}'
        path = next(folder.glob('*.xls'))
        book = xlrd.open_workbook(path)
        sheet = book.sheet_by_index(0)
        headers = sheet.row_values(2)
        serialized = []
        for i in range(sheet.nrows):
            serialized.append({'source_excel_row': i + 1, **{
                f'column_{j + 1:02d}': value for j, value in enumerate(sheet.row_values(i))}})
        matrix_exports.append((f'test_matrix_G{group}_source_cells.csv', serialized,
                               ['source_excel_row'] + [f'column_{j + 1:02d}' for j in range(sheet.ncols)]))
        for index in range(3, sheet.nrows):
            row = sheet.row_values(index)
            if not isinstance(row[0], (int, float)):
                continue
            # Each original matrix ends with the same six numeric feature/target cells.
            # Its legacy X5 and X6 headers map to X4 and X5 in the ML workbook.
            vals = row[-6:]
            if any(not isinstance(v, (int, float)) for v in vals):
                raise ValueError(f'Non-numeric feature in {path.name}, row {index + 1}')
            offset = 1 if group == 1 else 0
            tested = str(row[1])
            match = re.search(r'/(S\d+)', tested)
            config = re.search(r'E-([ABC])-(\d)', tested)
            if not match or not config:
                raise ValueError(f'Unrecognized specimen code: {tested}')
            specimen = match.group(1)
            axis = 'concentric' if vals[3] == 0 else 'not_recorded_in_matrix'
            note = str(row[3]).strip() if group == 1 else ''
            if 'weak axis' in note.lower():
                axis = 'weak_axis_as_recorded'
            elif 'strong axis' in note.lower():
                axis = 'strong_axis_as_recorded'
            major, minor = row[14 + offset], row[15 + offset]
            e, lam = row[4 + offset], row[5 + offset]
            denominator = ''
            if lam != 0:
                is_major = close(lam, e / major)
                is_minor = close(lam, e / minor)
                denominator = ('2ao_equals_2bo' if is_major and is_minor else
                               '2ao' if is_major else '2bo' if is_minor else 'unresolved')
            code = f'G{group}-{specimen}'
            c = {
                'case_id': code,
                'archive_group': f'Group-{group}',
                'fem_specimen_code': specimen,
                'tested_code_raw': tested,
                'base_configuration_id': f'{config.group(1)}-FRP{config.group(2)}',
                'source_test_matrix': path.relative_to(root).as_posix(),
                'source_test_matrix_sheet': sheet.name,
                'source_test_matrix_row': index + 1,
                'source_note': note,
                'source_condition': str(row[4] if group == 1 else row[3]).strip(),
                'source_author': str(row[2]).strip(),
                'loading_axis': axis,
                'lambda_normalizing_dimension': denominator,
                'eccentricity_mm': e,
                'lambda_matrix': lam,
                'concrete_strength_MPa': row[6 + offset],
                'confinement_condition_raw': row[7 + offset],
                'single_FRP_layer_thickness_mm': row[9 + offset],
                'FRP_layers': row[10 + offset],
                'total_FRP_thickness_mm': row[11 + offset],
                'FRP_tensile_strength_MPa': row[12 + offset],
                'FRP_modulus_MPa': row[13 + offset],
                'outer_major_dimension_mm': major,
                'outer_minor_dimension_mm': minor,
                'inner_major_dimension_mm': row[16 + offset],
                'inner_minor_dimension_mm': row[17 + offset],
                'steel_thickness_mm': row[18 + offset],
                'steel_yield_strength_MPa': row[19 + offset],
                'height_mm': row[20 + offset],
                'height_to_minor_dimension': row[21 + offset],
                **dict(zip(VALUES, vals)),
                'experimental_capacity_kN': row[23] if group == 1 and isinstance(row[23], (int, float)) else '',
            }
            cases.append(c)
    if len(cases) != 96 or len({c['case_id'] for c in cases}) != 96:
        raise ValueError('Expected 96 distinct group-qualified FEM cases')
    return cases, matrix_exports


def read_records(root, cases):
    path = root / 'data/raw/Data_for_ML_Topic37.xlsx'
    book = openpyxl.load_workbook(path, data_only=True, read_only=True)
    sheet = book['Sheet1']
    rows = list(sheet.iter_rows(values_only=True))
    if list(rows[0]) != VALUES or len(rows) != 109:
        raise ValueError('Unexpected source ML table schema or row count')
    output = []
    for index, values in enumerate(rows[1:], 2):
        if any(not isinstance(v, (int, float)) or not math.isfinite(v) for v in values):
            raise ValueError(f'Invalid numeric value in source row {index}')
        fem_matches = [c for c in cases if all(close(v, c[k]) for v, k in zip(values, VALUES))]
        exp_matches = [c for c in cases if c['experimental_capacity_kN'] != ''
                       and all(close(v, c[k]) for v, k in zip(values[:5], FEATURES))
                       and close(values[5], c['experimental_capacity_kN'])]
        if len(fem_matches) == 1 and not exp_matches:
            origin, case = 'FEM', fem_matches[0]
        elif len(exp_matches) == 1 and not fem_matches:
            origin, case = 'experimental', exp_matches[0]
        else:
            raise ValueError(f'Ambiguous origin/mapping in ML source row {index}')
        output.append({
            'record_id': f'ML{index - 1:04d}',
            'source_excel_row': index,
            'response_origin': origin,
            'loading_condition': 'concentric' if values[3] == 0 else 'eccentric',
            'case_id': case['case_id'],
            'base_configuration_id': case['base_configuration_id'],
            'archive_group': case['archive_group'],
            'fem_specimen_code': case['fem_specimen_code'],
            'tested_code_raw': case['tested_code_raw'],
            **dict(zip(VALUES, values)),
        })
    book.close()
    counts = collections.Counter(r['response_origin'] for r in output)
    if counts != {'FEM': 96, 'experimental': 12}:
        raise ValueError(f'Unexpected response origins: {counts}')
    return output


def read_curves(root, cases):
    case_map = {c['case_id']: c for c in cases}
    curves, summary, formula_audit, anomalies = [], [], [], []
    for group in range(1, 4):
        folder = root / 'data/raw/TESTS' / f'Group-{group}'
        path = next(folder.glob('*.xlsx'))
        formula_book = openpyxl.load_workbook(path, data_only=False)
        value_book = openpyxl.load_workbook(path, data_only=True)
        source = formula_book.active
        cached = value_book.active
        starts = [c.column for c in source[1] if c.value is not None]
        assigned_starts = set()
        for title_column in starts:
            specimen = str(source.cell(1, title_column).value).strip()
            case_id = f'G{group}-{specimen}'
            if case_id not in case_map:
                raise ValueError(f'Curve without test-matrix case: {case_id}')
            # G2-S287's specimen title sits above U3, two cells after its
            # actual Increment column. Resolve the containing response block
            # from its four explicit row-2 variable names, retaining the title
            # coordinate for audit instead of moving any source cells.
            candidates = [c for c in range(max(1, title_column - 3), title_column + 1)
                          if [str(source.cell(2, c + k).value).strip() for k in range(4)]
                          == ['Increment', 'E33', 'U3', 'RF (kN)']]
            if len(candidates) != 1 or candidates[0] in assigned_starts:
                raise ValueError(f'Ambiguous curve block: {case_id}: {candidates}')
            start = candidates[0]
            assigned_starts.add(start)
            series = []
            for row in range(3, source.max_row + 1):
                cells = [source.cell(row, start + k) for k in range(4)]
                values = [cached.cell(row, start + k).value for k in range(4)]
                if all(cell.value is None for cell in cells):
                    continue
                if any(isinstance(cell.value, str) and cell.data_type != 'f' for cell in cells):
                    anomalies.append({'case_id': case_id, 'row': row, 'reason': 'non-numeric curve cell'})
                    continue
                formula = cells[1].value if cells[1].data_type == 'f' else ''
                kind = ('formula_cached' if values[1] is not None else 'formula_uncached') if formula else 'literal'
                if formula:
                    formula_audit.append({'case_id': case_id,
                                          'source_file': path.relative_to(root).as_posix(),
                                          'source_cell': cells[1].coordinate,
                                          'formula': formula, 'cached_value': values[1],
                                          'cache_present': values[1] is not None})
                item = {
                    'case_id': case_id, 'archive_group': f'Group-{group}',
                    'source_file': path.relative_to(root).as_posix(),
                    'source_sheet': source.title, 'source_excel_row': row,
                    'source_title_cell': source.cell(1,title_column).coordinate,
                    'source_start_column': openpyxl.utils.get_column_letter(start),
                    'increment': values[0], 'E33': values[1], 'U3_mm': values[2], 'RF_kN': values[3],
                    'E33_cell_kind': kind, 'E33_formula': formula,
                }
                curves.append(item)
                series.append(item)
            valid = [r for r in series if isinstance(r['RF_kN'], (int, float))]
            peak = max(valid, key=lambda r: r['RF_kN'])
            target = case_map[case_id]['Y']
            summary.append({'case_id': case_id, 'curve_row_count': len(series),
                            'target_Y_kN': target, 'curve_peak_RF_kN': peak['RF_kN'],
                            'peak_minus_target_kN': peak['RF_kN'] - target,
                            'peak_source_excel_row': peak['source_excel_row'],
                            'peak_displacement_mm': peak['U3_mm'],
                            'source_file': path.relative_to(root).as_posix()})
        formula_book.close()
        value_book.close()
    if len(summary) != 96:
        raise ValueError('Expected 96 archived FEM curves')
    if anomalies:
        raise ValueError(f'Curve extraction anomalies: {anomalies}')
    return curves, summary, formula_audit


def dictionary_rows(records, cases, curves):
    definitions = {
        'record_id': ('', 'Identifier created for this package; ML workbook row order is preserved.'),
        'source_excel_row': ('', 'One-based Excel row, including source header rows.'),
        'response_origin': ('', 'FEM numerical output or reported experimental capacity; matched cases are not independent.'),
        'loading_condition': ('', 'Concentric when X4 equals zero; otherwise eccentric.'),
        'case_id': ('', 'Group-qualified FEM case identifier, also used to link the matched experimental observation.'),
        'base_configuration_id': ('', 'Cross-section family A/B/C and FRP layer count; shared by all eccentric variants of a base case.'),
        'archive_group': ('', 'Original TESTS archive group; different groups may reuse S specimen numbers.'),
        'fem_specimen_code': ('', 'S identifier from the supplied test matrix, not globally unique without archive_group.'),
        'tested_code_raw': ('', 'Original specimen code, including any # suffix.'),
        'X1': ('N/mm', 'FRP confinement stiffness: total FRP thickness multiplied by FRP elastic modulus.'),
        'X2': ('N', 'Steel tube resistance: steel cross-sectional area multiplied by steel yield strength.'),
        'X3': ('N', 'Concrete core resistance: concrete cross-sectional area multiplied by concrete strength.'),
        'X4': ('dimensionless', 'Recorded eccentricity ratio; normalizing cross-section dimension depends on case. Preserve source values.'),
        'X5': ('dimensionless', 'Outer major-to-minor dimension ratio: 2ao/2bo. The nominal 1.5 family has recorded ratio 230/154.'),
        'Y': ('kN', 'Ultimate capacity as stored in the ML workbook or corresponding test-matrix target.'),
        'source_test_matrix': ('', 'Relative path to original XLS test matrix.'),
        'source_test_matrix_sheet': ('', 'Original XLS worksheet title.'),
        'source_test_matrix_row': ('', 'One-based source XLS row for the FEM configuration.'),
        'source_note': ('', 'Group-1 NOTE column copied literally after trimming surrounding whitespace.'),
        'source_condition': ('', 'Original matrix Condition field.'),
        'source_author': ('', 'Original matrix Author field; PARAMETRIC marks numerical cases.'),
        'loading_axis': ('', 'Axis explicitly recorded in Group-1 NOTE; otherwise marked not_recorded_in_matrix. No axis is inferred for G2/G3.'),
        'lambda_normalizing_dimension': ('', 'Dimension that numerically satisfies lambda=e/dimension; blank for concentric cases.'),
        'eccentricity_mm': ('mm', 'Eccentric distance copied from source test matrix.'),
        'lambda_matrix': ('dimensionless', 'Lamba field copied from source test matrix.'),
        'concrete_strength_MPa': ('MPa', 'Standard concrete strength copied from source test matrix.'),
        'confinement_condition_raw': ('', 'Original Confinement Condition field; source dash is retained.'),
        'single_FRP_layer_thickness_mm': ('mm', 'Source layer thickness. Unwrapped rows retain their recorded zero.'),
        'FRP_layers': ('count', 'Number of FRP layers, copied from source.'),
        'total_FRP_thickness_mm': ('mm', 'Total FRP thickness, copied from source.'),
        'FRP_tensile_strength_MPa': ('MPa', 'Source tensile strength. Unwrapped rows retain their recorded zero.'),
        'FRP_modulus_MPa': ('MPa', 'Source FRP elastic modulus. Unwrapped rows retain their recorded zero.'),
        'outer_major_dimension_mm': ('mm', 'Source outer full major dimension 2ao.'),
        'outer_minor_dimension_mm': ('mm', 'Source outer full minor dimension 2bo.'),
        'inner_major_dimension_mm': ('mm', 'Source inner full major dimension 2ai.'),
        'inner_minor_dimension_mm': ('mm', 'Source inner full minor dimension 2bi.'),
        'steel_thickness_mm': ('mm', 'Source steel tube thickness ts.'),
        'steel_yield_strength_MPa': ('MPa', 'Source steel yield strength.'),
        'height_mm': ('mm', 'Source column height.'),
        'height_to_minor_dimension': ('dimensionless', 'Source height/full minor dimension, H/(2bo).'),
        'experimental_capacity_kN': ('kN', 'Experimental Load field for 12 Group-1 baseline cases; blank for cases without an experimental response.'),
        'source_file': ('', 'Relative path to original FEM response workbook.'),
        'source_sheet': ('', 'Original FEM response worksheet title.'),
        'source_start_column': ('', 'Excel column containing the beginning of a four-column specimen block.'),
        'source_title_cell': ('', 'Original Excel coordinate of the specimen title, retained even when offset within its response block.'),
        'increment': ('source units not specified', 'Recorded Increment field; no assumption that this is a count or elapsed seconds.'),
        'E33': ('dimensionless', 'Recorded E33 value. Some source cells are formulas U3/500; these are nominal displacement/height values.'),
        'U3_mm': ('mm', 'Recorded axial displacement U3; source sign is preserved.'),
        'RF_kN': ('kN', 'Recorded axial reaction force; source sign is preserved.'),
        'E33_cell_kind': ('', 'literal, formula_cached, or formula_uncached, based on the original E33 cell.'),
        'E33_formula': ('', 'Original E33 Excel formula when present; blank for literal cells.'),
    }
    ranges = collections.defaultdict(list)
    for rows in (records, cases, curves):
        for row in rows:
            for k, v in row.items():
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    ranges[k].append(v)
    out = []
    for table, rows in [('records_all.csv; fem_ml.csv; experimental_concentric.csv', records),
                        ('fem_case_metadata.csv', cases), ('fem_curves_long.csv', curves)]:
        for field in rows[0]:
            if field not in definitions:
                raise ValueError(f'Missing dictionary definition: {field}')
            unit, definition = definitions[field]
            nums = [r[field] for r in rows if isinstance(r[field], (int, float)) and not isinstance(r[field], bool)]
            out.append({'table': table, 'column': field, 'unit': unit,
                        'definition': definition, 'observed_min': min(nums) if nums else '',
                        'observed_max': max(nums) if nums else '',
                        'missing_value_policy': 'Blank denotes absent metadata/cell. Recorded numeric zero is retained.'})
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset-root', type=Path, default=ROOT)
    parser.add_argument('--overwrite', action='store_true')
    args = parser.parse_args()
    root = args.dataset_root.resolve()
    if (root / 'data/processed/records_all.csv').exists() and not args.overwrite:
        parser.error('Generated files already exist. Use --overwrite only to rebuild them.')
    cases, matrix_exports = read_matrices(root)
    records = read_records(root, cases)
    curves, curve_summary, formula_audit = read_curves(root, cases)
    fem = [r for r in records if r['response_origin'] == 'FEM']
    experimental = [r for r in records if r['response_origin'] == 'experimental']
    columns = list(records[0])
    for name, rows in [('records_all.csv', records), ('fem_ml.csv', fem),
                        ('experimental_concentric.csv', experimental)]:
        write_csv(root / 'data/processed' / name, rows, columns)
    write_csv(root / 'data/processed/fem_case_metadata.csv', cases, list(cases[0]))
    write_csv(root / 'data/processed/fem_curves_long.csv', curves, list(curves[0]))
    write_csv(root / 'data/processed/fem_curve_summary.csv', curve_summary, list(curve_summary[0]))
    write_csv(root / 'metadata/source_formula_audit.csv', formula_audit, list(formula_audit[0]))
    for name, rows, columns in matrix_exports:
        write_csv(root / 'data/source_exports' / name, rows, columns)
    write_csv(root / 'data/source_exports/ML_source_108.csv',
              [{k: r[k] for k in VALUES} for r in records], VALUES)
    dictionary = dictionary_rows(records, cases, curves)
    write_csv(root / 'docs/data_dictionary.csv', dictionary, list(dictionary[0]))
    grouped = collections.defaultdict(list)
    for row in fem:
        grouped[tuple(row[k] for k in FEATURES)].append(row)
    collisions = [rows for rows in grouped.values() if len(rows) > 1]
    collision_records = []
    for i, rows in enumerate(collisions, 1):
        for row in rows:
            collision_records.append({'collision_id': i, 'record_id': row['record_id'],
                                      'source_excel_row': row['source_excel_row'], 'case_id': row['case_id'],
                                      **{k: row[k] for k in VALUES}})
    write_csv(root / 'metadata/fem_predictor_collisions.csv', collision_records,
              ['collision_id','record_id','source_excel_row','case_id'] + VALUES)
    comparisons = []
    for row in experimental:
        twin = next(r for r in fem if r['case_id'] == row['case_id'])
        comparisons.append({'case_id': row['case_id'], 'base_configuration_id': row['base_configuration_id'],
                            'experimental_source_excel_row': row['source_excel_row'],
                            'FEM_source_excel_row': twin['source_excel_row'],
                            'experimental_Y_kN': row['Y'], 'FEM_Y_kN': twin['Y'],
                            'FEM_over_experimental': twin['Y'] / row['Y']})
    write_csv(root / 'data/processed/concentric_validation_pairs.csv', comparisons, list(comparisons[0]))
    report = {
        'release_version': '1.0.0', 'numeric_source_values_modified': False,
        'record_count': len(records), 'fem_count': len(fem), 'experimental_count': len(experimental),
        'fem_concentric_count': sum(r['loading_condition'] == 'concentric' for r in fem),
        'fem_eccentric_count': sum(r['loading_condition'] == 'eccentric' for r in fem),
        'experimental_source_excel_rows': [r['source_excel_row'] for r in experimental],
        'missing_core_numeric_cells': sum(r[k] is None for r in records for k in VALUES),
        'unique_base_configurations': len({r['base_configuration_id'] for r in fem}),
        'fem_records_per_base_configuration': dict(sorted(collections.Counter(r['base_configuration_id'] for r in fem).items())),
        'fem_records_per_archive_group': dict(collections.Counter(r['archive_group'] for r in fem)),
        'source_matrix_matches_verified': len(fem), 'experimental_pairs_verified': len(comparisons),
        'curve_case_count': len(curve_summary), 'curve_row_count': len(curves),
        'original_formula_cells_audited': len(formula_audit),
        'missing_formula_cache_count': sum(not r['cache_present'] for r in formula_audit),
        'fem_identical_predictor_groups': len(collisions),
        'fem_records_in_identical_predictor_groups': sum(map(len, collisions)),
        'exact_duplicate_six_column_records': len(records) - len({tuple(r[k] for k in VALUES) for r in records}),
        'max_abs_curve_peak_minus_target_kN': max(abs(r['peak_minus_target_kN']) for r in curve_summary),
        'curve_peaks_differing_by_more_than_0_01_kN': [r['case_id'] for r in curve_summary if abs(r['peak_minus_target_kN']) > 0.01],
        'mean_concentric_FEM_over_experimental': statistics.mean(r['FEM_over_experimental'] for r in comparisons),
        'feature_ranges_FEM': {k: {'min': min(r[k] for r in fem), 'max': max(r[k] for r in fem)} for k in VALUES},
        'source_files_opened_read_only': True,
        'notes': [
            'FEM responses are numerical simulation outputs; experimental responses are separately labelled.',
            'Eight FEM predictor pairs have identical X1-X5 with different Y; all are retained as distinct archived cases.',
            'The loading axis is explicitly recorded in Group-1 but not in Group-2/3 test-matrix columns.',
            'Formula values in curve CSVs use stored Excel caches; original formulas and workbooks are retained.',
            'Any curve peak/target differences are reported without replacing the original target Y.',
            'G2-S287 title is at BW1, while its response block starts at BU; row-2 variable names identify the correct cells.',
            'No solver input decks, trained models, original random-partition membership or publication DOI are generated.'
        ]
    }
    report_path = root / 'metadata/quality_report.json'
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({k: report[k] for k in ['record_count','fem_count','experimental_count',
                    'curve_case_count','curve_row_count','original_formula_cells_audited',
                    'fem_identical_predictor_groups','max_abs_curve_peak_minus_target_kN',
                    'mean_concentric_FEM_over_experimental']}, indent=2))


if __name__ == '__main__':
    main()
