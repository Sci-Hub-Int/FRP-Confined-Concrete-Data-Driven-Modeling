# FRP confined elliptical CFST column dataset

This release contains the feature matrix, reported experimental capacities, numerical FEM capacities, archived response curves and field images accompanying the manuscript **Data-Driven Prediction of Load-Bearing Capacity in FRP-Confined Elliptical CFST Columns Using Ensemble Machine Learning Techniques**.

The primary machine-learning table is `data/processed/fem_ml.csv`. It contains **96 FEM cases**, with five predictors and ultimate capacity in kN. The **12 reported experimental capacities** are provided separately for the matched concentric validation cases. The complete 108-row source matrix is also preserved. All original numeric values and all 222 files extracted from the supplied TESTS archive are retained.

## Data at a glance

| Component | Coverage | Main file |
| --- | ---: | --- |
| Complete source matrix | 108 response records | `data/processed/records_all.csv` |
| FEM prediction dataset | 96 cases: 12 concentric and 84 eccentric | `data/processed/fem_ml.csv` |
| Experimental reference capacities | 12 concentric observations | `data/processed/experimental_concentric.csv` |
| Base configurations | 12 geometry and FRP combinations | `data/processed/fem_case_metadata.csv` |
| Archived FEM response curves | 96 cases, 959 available response rows | `data/processed/fem_curves_long.csv` |
| Original test matrices and response workbooks | 3 XLS and 3 XLSX files | `data/raw/TESTS/` |
| Original FEM field images | 216 TIFF files | `data/raw/TESTS/` |
| Paired concentric validation | 12 FEM/experimental pairs | `data/processed/concentric_validation_pairs.csv` |

Release version: **1.0.0**. Package preparation date: **2026-10-13**. This date identifies the release preparation, not the date of the original experiments or simulations.

## Feature definitions

| Column | Meaning | Unit |
| --- | --- | --- |
| `X1` | Total FRP thickness multiplied by FRP elastic modulus | N/mm |
| `X2` | Steel cross-sectional area multiplied by steel yield strength | N |
| `X3` | Concrete core area multiplied by concrete compressive strength | N |
| `X4` | Recorded eccentricity ratio | Dimensionless |
| `X5` | Outer major-to-minor dimension ratio | Dimensionless |
| `Y` | Recorded ultimate capacity | kN |

The dimensional units of `X2` and `X3` are **N**, while the target `Y` is **kN**. These features are structural resistance descriptors and are not interchangeable with the target. The file `docs/data_dictionary.csv` describes every column in the main tables, including identifiers and source coordinates.

## Start here

Unzip the release and open this folder. Python 3.10 or later is required for the included preparation and validation scripts. Install the package's dependencies if they are not already available:

```bash
python -m pip install -r requirements.txt
python scripts/validate_dataset.py
python scripts/load_dataset.py
```

The basic Python loader uses the standard library and can run without installing these dependencies. It returns `X`, `y`, base-configuration groups and the annotated source records:

```python
import sys
sys.path.insert(0, "scripts")
from load_dataset import load_fem_dataset

X, y, groups, records = load_fem_dataset()
```

For MATLAB, add `scripts` to the path and call:

```matlab
addpath('scripts');
[X, y, groups, records] = load_fem_dataset;
```

To regenerate the tabular exports from the retained source Excel files, use the explicit overwrite flag:

```bash
python scripts/prepare_dataset.py --overwrite
```

This regenerates processed CSVs, dictionary and audit reports. It preserves the original workbooks. After changing any release file, refresh the manifest using `python scripts/refresh_manifest.py`, then validate again.

## File organization

| Folder or file | Purpose |
| --- | --- |
| `data/raw/` | Original ML workbook and unchanged extracted TESTS files |
| `data/processed/` | Annotated records, separate response origins, FEM metadata, curves and validation pairs |
| `data/source_exports/` | Direct six-column ML export and cell-indexed exports of all XLS test matrices |
| `docs/` | Dictionary, provenance, methodological scope and audit findings |
| `metadata/` | Repository metadata, source hashes, formula audit, predictor-collision audit and file manifest |
| `scripts/` | Rebuild, validation, Python/MATLAB loading and checksum scripts |
| `checksums.sha256` | SHA-256 integrity list for release files |

## Data interpretation and evaluation

Use `fem_ml.csv` for the numerical prediction task described in the manuscript. Use `experimental_concentric.csv` and `concentric_validation_pairs.csv` for comparison with the concentric experimental reference capacities. Experimental and FEM records of a matched configuration are not independent observations.

`base_configuration_id` identifies the 12 cross-section/FRP combinations. It is a grouping variable, not an extra numeric predictor. A group-separated evaluation should keep all variants of each base configuration together and fit scaling or feature selection only on the training portion. No new training/test assignment is claimed to reproduce the historical random partition.

Some source records have identical `X1`–`X5` but different responses. These cases are retained and documented in `metadata/fem_predictor_collisions.csv`. The original five-feature matrix does not include a loading-axis descriptor. Group-1 explicitly records the axis in its test-matrix notes; Group-2 and Group-3 do not contain an equivalent explicit axis field.

Three archived curve maxima differ from the corresponding stored ultimate-capacity targets. Both quantities are preserved, and the differences are reported in `docs/QUALITY_REPORT.md` and `fem_curve_summary.csv`. The primary targets remain the values that agree between the supplied ML workbook and test matrices.

## Provenance and release scope

The source files are those supplied with the manuscript. The experimental reference capacities are attributed in that manuscript to Zeng et al. (2021). This package preserves their reported, configuration-level values; it does not create individual results for the I/II specimen pairs.

The response curves and images are archived FEM outputs. The release includes the available sampled responses and stored Excel formula caches. It does not reconstruct missing solver output between those samples. See `docs/PROVENANCE.md` and `docs/METHODOLOGY.md` for exact mapping and scope.

This is a dataset release with preparation and validation utilities. Abaqus input decks, solver databases, trained ML models and the original GUI project were not included in the supplied attachments and are not represented as deposited here.

## Citation and repository metadata

The related manuscript title and author names, as listed in the supplied manuscript, are recorded in `metadata/repository_metadata.json` and `CITATION.md`. No dataset DOI, journal DOI or repository URL has been assigned by this package. Add the identifier and final dataset creators supplied by the repository after deposit. No redistribution license was specified in the attachments; select the appropriate license when creating the repository record.
